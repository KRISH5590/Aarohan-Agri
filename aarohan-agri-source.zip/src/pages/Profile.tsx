import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BadgeCheck, Camera, FlaskConical, Sprout, Star, Trophy, IndianRupee } from 'lucide-react';
import { FARMER_NAME, FARMER_VILLAGE } from '@/lib/mockData';

const Profile = () => {
  return (
    <div className="container py-6 space-y-6">
      <Card className="card-leaf p-6">
        <div className="flex items-start gap-5 flex-wrap">
          <div className="relative">
            <div className="h-24 w-24 rounded-2xl gradient-primary flex items-center justify-center text-primary-foreground font-heading text-3xl font-bold shadow-card">
              RP
            </div>
            <button className="absolute -bottom-2 -right-2 h-9 w-9 rounded-full bg-accent text-accent-foreground flex items-center justify-center shadow-glow">
              <Camera className="h-4 w-4" />
            </button>
          </div>
          <div className="flex-1 min-w-[200px]">
            <h1 className="font-heading text-2xl font-bold">{FARMER_NAME}</h1>
            <p className="text-muted-foreground">{FARMER_VILLAGE} • 12 years farming</p>
            <p className="text-sm mt-1">Crops grown: <span className="font-semibold">Soybean, Wheat, Gram</span></p>
            <div className="flex flex-wrap gap-2 mt-3">
              <Badge className="bg-success text-success-foreground gap-1"><FlaskConical className="h-3 w-3" />Lab Certified</Badge>
              <Badge className="bg-primary text-primary-foreground gap-1"><Sprout className="h-3 w-3" />IoT Monitored</Badge>
              <Badge className="bg-accent text-accent-foreground gap-1"><Trophy className="h-3 w-3" />Top Seller</Badge>
              <Badge className="bg-secondary text-secondary-foreground gap-1"><BadgeCheck className="h-3 w-3" />Verified Farmer</Badge>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="card-leaf p-5">
          <h3 className="font-heading font-bold mb-2">Profile Completeness</h3>
          <Progress value={78} className="h-2" />
          <div className="text-sm mt-2">78% complete</div>
          <div className="space-y-2 mt-4 text-sm">
            {[
              { label: 'Basic info', done: true },
              { label: 'Lab certificate', done: true },
              { label: 'Bank details', done: true },
              { label: 'Aadhaar/KYC', done: false },
              { label: 'Land records', done: false },
            ].map(t => (
              <div key={t.label} className="flex items-center justify-between">
                <span className={t.done ? 'text-muted-foreground line-through' : ''}>{t.label}</span>
                {t.done ? <BadgeCheck className="h-4 w-4 text-success" /> : <Button size="sm" variant="ghost" className="h-6 text-xs">Add</Button>}
              </div>
            ))}
          </div>
        </Card>

        <Card className="card-leaf p-5">
          <h3 className="font-heading font-bold mb-3">Rating Breakdown</h3>
          <div className="text-center mb-3">
            <div className="font-heading text-4xl font-bold text-accent">4.9</div>
            <div className="flex justify-center gap-0.5">{[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-accent text-accent" />)}</div>
            <div className="text-xs text-muted-foreground mt-1">Based on 87 reviews</div>
          </div>
          {[
            { label: 'Quality', value: 98 },
            { label: 'Timeliness', value: 92 },
            { label: 'Communication', value: 89 },
          ].map(r => (
            <div key={r.label} className="mb-2">
              <div className="flex justify-between text-xs mb-1"><span>{r.label}</span><span className="font-semibold">{r.value}%</span></div>
              <Progress value={r.value} className="h-1.5" />
            </div>
          ))}
        </Card>

        <Card className="card-leaf p-5">
          <h3 className="font-heading font-bold mb-3">Earnings</h3>
          <div className="p-4 rounded-xl gradient-primary text-primary-foreground text-center">
            <IndianRupee className="h-6 w-6 mx-auto opacity-80" />
            <div className="font-heading text-3xl font-bold mt-1">14.2L</div>
            <div className="text-xs opacity-90">Lifetime earnings</div>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-3 text-center text-sm">
            <div className="p-3 rounded-lg bg-secondary"><div className="text-xs text-muted-foreground">This month</div><div className="font-bold">₹2.6L</div></div>
            <div className="p-3 rounded-lg bg-secondary"><div className="text-xs text-muted-foreground">Transactions</div><div className="font-bold">142</div></div>
          </div>
        </Card>
      </div>

      <Card className="card-leaf p-5">
        <h3 className="font-heading font-bold mb-4">KYC / Aadhaar Verification</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div><Label>Aadhaar Number</Label><Input placeholder="XXXX XXXX XXXX" maxLength={14} /></div>
          <div><Label>PAN (optional)</Label><Input placeholder="ABCDE1234F" /></div>
          <div><Label>Bank Account</Label><Input placeholder="Account number" /></div>
          <div><Label>IFSC Code</Label><Input placeholder="SBIN0001234" /></div>
        </div>
        <Button className="mt-4 gradient-primary text-primary-foreground">Verify & Save</Button>
      </Card>
    </div>
  );
};

export default Profile;
