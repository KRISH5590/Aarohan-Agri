import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, CloudRain, Sparkles, MapPin, Calendar } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, Area, AreaChart } from 'recharts';
import { demandForecast } from '@/lib/mockData';

const heatmapData = ['Wheat','Soybean','Gram','Onion','Tomato','Mustard'].map(crop => ({
  crop,
  months: Array.from({ length: 12 }, () => Math.round(Math.random() * 100)),
}));

const districts = [
  { name: 'Indore', price: 5230, change: '+3.4%' },
  { name: 'Bhopal', price: 5180, change: '+2.1%' },
  { name: 'Ujjain', price: 5210, change: '+2.8%' },
  { name: 'Dewas', price: 5160, change: '+1.5%' },
  { name: 'Sehore', price: 5200, change: '+2.4%' },
  { name: 'Ratlam', price: 5190, change: '+2.0%' },
];

const Insights = () => {
  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold">📈 AI Insights</h1>
        <p className="text-muted-foreground mt-1">Data-driven decisions for maximum profit</p>
      </div>

      {/* Top alerts */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="card-leaf p-5 border-l-success">
          <div className="flex items-center gap-2 mb-2"><TrendingUp className="h-5 w-5 text-success" /><span className="font-bold">Demand Forecast</span></div>
          <p className="text-sm">Soybean demand in Indore — next 30 days: <Badge className="bg-success text-success-foreground ml-1">📈 High</Badge></p>
        </Card>
        <Card className="card-leaf p-5 border-l-blue-500">
          <div className="flex items-center gap-2 mb-2"><CloudRain className="h-5 w-5 text-blue-500" /><span className="font-bold">Weather Alert</span></div>
          <p className="text-sm">Unseasonal rain expected in 4 days — store crops now to avoid loss</p>
        </Card>
        <Card className="card-leaf p-5 border-l-accent">
          <div className="flex items-center gap-2 mb-2"><Sparkles className="h-5 w-5 text-accent" /><span className="font-bold">Festival Surge</span></div>
          <p className="text-sm">Diwali approaching — Dry fruits demand up <span className="font-bold text-accent">40%</span></p>
        </Card>
      </div>

      <Card className="card-leaf p-5">
        <h3 className="font-heading font-bold mb-3">7-Day Forward Price Prediction (Soybean)</h3>
        <ResponsiveContainer width="100%" height={280}>
          <AreaChart data={demandForecast}>
            <defs>
              <linearGradient id="conf" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.4} />
                <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
            <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))' }} />
            <Area type="monotone" dataKey="forecast" stroke="hsl(var(--accent))" fill="url(#conf)" strokeWidth={2.5} />
            <Line type="monotone" dataKey="demand" stroke="hsl(var(--primary))" strokeWidth={2.5} dot={false} />
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex gap-4 text-xs mt-2">
          <span className="inline-flex items-center gap-1"><span className="h-2 w-3 rounded bg-primary" />Actual</span>
          <span className="inline-flex items-center gap-1"><span className="h-2 w-3 rounded bg-accent" />Forecast (95% confidence)</span>
        </div>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="card-leaf p-5">
          <h3 className="font-heading font-bold mb-3">Seasonal Pattern Heatmap</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr><th className="text-left p-1"></th>{['J','F','M','A','M','J','J','A','S','O','N','D'].map(m => <th key={m} className="p-1">{m}</th>)}</tr></thead>
              <tbody>
                {heatmapData.map(row => (
                  <tr key={row.crop}>
                    <td className="p-1 font-semibold pr-2">{row.crop}</td>
                    {row.months.map((v, i) => (
                      <td key={i} className="p-0.5">
                        <div className="h-7 w-full rounded" style={{ backgroundColor: `hsl(122 61% ${Math.max(20, 90 - v * 0.6)}%)` }} title={`${v}%`} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card className="card-leaf p-5">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="h-5 w-5 text-accent" />
            <h3 className="font-heading font-bold">Best Time to Sell</h3>
          </div>
          <div className="space-y-3">
            {[
              { crop: 'Soybean', when: 'Next 5 days', reason: 'Peak demand from oil mills' },
              { crop: 'Wheat', when: 'After 15 days', reason: 'Govt MSP procurement starts' },
              { crop: 'Onion', when: 'Hold 30+ days', reason: 'Storage now, sell pre-Diwali' },
            ].map(r => (
              <div key={r.crop} className="p-3 rounded-lg bg-secondary">
                <div className="flex items-center justify-between">
                  <span className="font-bold">{r.crop}</span>
                  <Badge className="bg-accent text-accent-foreground">{r.when}</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{r.reason}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="card-leaf p-5">
        <div className="flex items-center gap-2 mb-3">
          <MapPin className="h-5 w-5 text-primary" />
          <h3 className="font-heading font-bold">India-wide Mandi Price Map (MP Districts)</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {districts.map(d => (
            <div key={d.name} className="p-3 rounded-xl bg-gradient-to-br from-primary/10 to-accent/10 border border-border text-center hover:shadow-card transition cursor-pointer">
              <div className="font-bold">{d.name}</div>
              <div className="font-heading text-xl text-primary mt-1">₹{d.price}</div>
              <div className="text-xs text-success font-semibold mt-1">{d.change}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Insights;
