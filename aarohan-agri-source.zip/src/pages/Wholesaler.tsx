import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Search, BadgeCheck, QrCode, Star, Filter, Download } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const farmerListings = [
  { id: 1, name: 'Ramesh Patel', village: 'Mhow', crop: 'Soybean', qty: 50, grade: 'A', price: 5230, lab: true, iot: true, rating: 4.9 },
  { id: 2, name: 'Sunita Devi', village: 'Ujjain', crop: 'Wheat', qty: 80, grade: 'A+', price: 2480, lab: true, iot: false, rating: 4.7 },
  { id: 3, name: 'Mahesh Kumar', village: 'Dewas', crop: 'Gram', qty: 30, grade: 'B', price: 5750, lab: true, iot: true, rating: 4.8 },
  { id: 4, name: 'Priya Yadav', village: 'Sehore', crop: 'Onion', qty: 120, grade: 'A', price: 1900, lab: false, iot: false, rating: 4.5 },
];

const orders = [
  { id: 'O-2401', farmer: 'Ramesh Patel', crop: 'Soybean 50q', status: 'In Transit', amount: 261500 },
  { id: 'O-2398', farmer: 'Sunita Devi', crop: 'Wheat 80q', status: 'Delivered', amount: 198400 },
  { id: 'O-2395', farmer: 'Mahesh Kumar', crop: 'Gram 30q', status: 'Confirmed', amount: 172500 },
  { id: 'O-2390', farmer: 'Priya Yadav', crop: 'Onion 120q', status: 'Pending', amount: 228000 },
];

const statusColor: Record<string, string> = {
  Pending: 'bg-warning text-warning-foreground',
  Confirmed: 'bg-primary text-primary-foreground',
  'In Transit': 'bg-accent text-accent-foreground',
  Delivered: 'bg-success text-success-foreground',
};

const Wholesaler = () => {
  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold">🏪 Wholesaler Dashboard</h1>
        <p className="text-muted-foreground mt-1">Browse certified farmer listings — verified, traceable, fair priced</p>
      </div>

      <Tabs defaultValue="browse">
        <TabsList className="grid grid-cols-3 max-w-xl">
          <TabsTrigger value="browse">Browse Listings</TabsTrigger>
          <TabsTrigger value="orders">My Orders</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-4 pt-4">
          <Card className="p-4">
            <div className="flex flex-wrap gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search crop, region, farmer…" className="pl-10" />
              </div>
              <Button variant="outline" className="gap-2"><Filter className="h-4 w-4" />Filters</Button>
              <Button variant="outline" className="gap-2" onClick={() => toast({ title: 'QR scanner activated' })}><QrCode className="h-4 w-4" />Scan QR</Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              {['Lab Certified ✅', 'IoT Monitored', 'Delivery Available', 'Negotiable'].map(f => (
                <Badge key={f} variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition">{f}</Badge>
              ))}
            </div>
          </Card>

          <div className="grid md:grid-cols-2 gap-4">
            {farmerListings.map(f => (
              <Card key={f.id} className="card-leaf p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-heading font-bold">{f.name}</h3>
                      <BadgeCheck className="h-4 w-4 text-success" />
                    </div>
                    <div className="text-xs text-muted-foreground">{f.village} • ⭐ {f.rating}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-heading text-xl font-bold text-primary">₹{f.price}</div>
                    <div className="text-xs text-muted-foreground">/quintal</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3 text-sm">
                  <div className="p-2 rounded-lg bg-secondary text-center">
                    <div className="text-[10px] text-muted-foreground uppercase">Crop</div>
                    <div className="font-bold">{f.crop}</div>
                  </div>
                  <div className="p-2 rounded-lg bg-secondary text-center">
                    <div className="text-[10px] text-muted-foreground uppercase">Qty</div>
                    <div className="font-bold">{f.qty}q</div>
                  </div>
                  <div className="p-2 rounded-lg bg-secondary text-center">
                    <div className="text-[10px] text-muted-foreground uppercase">Grade</div>
                    <div className="font-bold">{f.grade}</div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {f.lab && <Badge className="bg-success text-success-foreground text-[10px]">Lab Certified</Badge>}
                  {f.iot && <Badge className="bg-primary text-primary-foreground text-[10px]">IoT Monitored</Badge>}
                </div>
                <div className="flex gap-2 mt-3">
                  <Button className="flex-1 gradient-primary text-primary-foreground" onClick={() => toast({ title: `Offer placed to ${f.name}` })}>Place Offer</Button>
                  <Button variant="outline" onClick={() => toast({ title: 'Counter offer flow' })}>Counter</Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="orders" className="pt-4 space-y-3">
          {orders.map(o => (
            <Card key={o.id} className="card-leaf p-4 flex items-center justify-between flex-wrap gap-3">
              <div>
                <div className="font-bold">{o.id} • {o.farmer}</div>
                <div className="text-xs text-muted-foreground">{o.crop}</div>
              </div>
              <Badge className={statusColor[o.status]}>{o.status}</Badge>
              <div className="font-heading font-bold text-primary">₹{o.amount.toLocaleString('en-IN')}</div>
              <Button variant="outline" size="sm" className="gap-1"><Download className="h-3 w-3" />Invoice</Button>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="history" className="pt-4">
          <Card className="p-5">
            <h3 className="font-heading font-bold mb-3">Transaction History</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 rounded-xl bg-secondary"><div className="text-xs text-muted-foreground">Total Orders</div><div className="font-heading text-2xl font-bold text-primary">142</div></div>
              <div className="p-4 rounded-xl bg-secondary"><div className="text-xs text-muted-foreground">Total Spent</div><div className="font-heading text-2xl font-bold text-primary">₹38.4L</div></div>
              <div className="p-4 rounded-xl bg-secondary"><div className="text-xs text-muted-foreground">Avg Rating Given</div><div className="font-heading text-2xl font-bold text-accent inline-flex items-center gap-1"><Star className="h-5 w-5 fill-accent" />4.7</div></div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Wholesaler;
