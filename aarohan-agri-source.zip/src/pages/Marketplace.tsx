import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BadgeCheck, MapPin, MessageSquare, QrCode, Sparkles, Star, Upload } from 'lucide-react';
import { buyerOffers } from '@/lib/mockData';
import { toast } from '@/hooks/use-toast';

const Marketplace = () => {
  const [sortBy, setSortBy] = useState('price');
  const sorted = [...buyerOffers].sort((a, b) =>
    sortBy === 'price' ? b.price - a.price : sortBy === 'distance' ? a.distance - b.distance : b.rating - a.rating
  );

  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold">Crop Marketplace</h1>
        <p className="text-muted-foreground mt-1">List your crop and receive offers from verified wholesalers</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* List crop form */}
        <Card className="card-leaf p-6">
          <h2 className="font-heading text-lg font-bold mb-4">📦 List My Crop</h2>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Crop Type</Label>
                <Select defaultValue="soybean">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="soybean">Soybean</SelectItem>
                    <SelectItem value="wheat">Wheat</SelectItem>
                    <SelectItem value="gram">Gram</SelectItem>
                    <SelectItem value="onion">Onion</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Quantity (Quintals)</Label>
                <Input type="number" defaultValue={50} />
              </div>
            </div>
            <div>
              <Label>Location</Label>
              <Input defaultValue="Mhow, Indore (MP)" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Harvest Date</Label>
                <Input type="date" />
              </div>
              <div>
                <Label>Quality Grade</Label>
                <Select defaultValue="A">
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Grade A (Premium)</SelectItem>
                    <SelectItem value="B">Grade B (Standard)</SelectItem>
                    <SelectItem value="C">Grade C (Basic)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Lab Certificate</Label>
              <button type="button" className="w-full h-24 rounded-lg border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition flex flex-col items-center justify-center gap-1">
                <Upload className="h-5 w-5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Upload PDF/Image</span>
              </button>
            </div>

            {/* AI price suggestion */}
            <div className="p-4 rounded-xl bg-accent/10 border border-accent/30">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="h-4 w-4 text-accent" />
                <span className="text-sm font-bold text-accent">AI Price Suggestion</span>
              </div>
              <p className="text-sm">Based on Indore mandi rate, suggested price: <span className="font-bold">₹5,100 – ₹5,400/quintal</span></p>
            </div>

            <Tabs defaultValue="now">
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="now">Sell Now</TabsTrigger>
                <TabsTrigger value="later">Store & Sell Later</TabsTrigger>
              </TabsList>
            </Tabs>

            <Button className="w-full h-12 gradient-primary text-primary-foreground font-semibold" onClick={() => toast({ title: '✅ Crop listed!', description: '4 buyer offers received' })}>
              List Crop & Get Offers
            </Button>

            <Button variant="outline" className="w-full gap-2" onClick={() => toast({ title: 'QR generated for batch SOY-2025-0042' })}>
              <QrCode className="h-4 w-4" /> Generate QR for Batch Traceability
            </Button>
          </div>
        </Card>

        {/* Live offers */}
        <div className="space-y-4">
          <Card className="p-4">
            <div className="flex items-center gap-2 justify-between flex-wrap">
              <h2 className="font-heading font-bold">Live Buyer Offers ({buyerOffers.length})</h2>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-44 h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="price">Highest Price</SelectItem>
                  <SelectItem value="distance">Nearest</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Card>

          {sorted.map((b, i) => (
            <motion.div key={b.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="card-leaf p-4">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex-1 min-w-[180px]">
                    <div className="flex items-center gap-2">
                      <h3 className="font-heading font-bold">{b.name}</h3>
                      {b.verified && <BadgeCheck className="h-4 w-4 text-success" />}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                      <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {b.distance} km</span>
                      <span className="inline-flex items-center gap-1"><Star className="h-3 w-3 fill-accent text-accent" /> {b.rating}</span>
                      <Badge variant="secondary" className="text-[10px]">Pickup: {b.pickup}</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-heading text-2xl font-bold text-primary">₹{b.price}</div>
                    <div className="text-xs text-muted-foreground">per quintal</div>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" className="flex-1 gradient-primary text-primary-foreground" onClick={() => toast({ title: `Accepted offer from ${b.name}` })}>Accept Offer</Button>
                  <Button size="sm" variant="outline" className="gap-1" onClick={() => toast({ title: `Chat opened with ${b.name}` })}>
                    <MessageSquare className="h-4 w-4" /> Negotiate
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}

          {/* Map placeholder */}
          <Card className="p-4">
            <h3 className="font-heading font-bold mb-2">Buyer Locations</h3>
            <div className="h-48 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center border border-border">
              <div className="text-center">
                <MapPin className="h-8 w-8 mx-auto text-primary mb-2" />
                <p className="text-sm text-muted-foreground">Map view — 4 buyers within 35km of your farm</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Marketplace;
