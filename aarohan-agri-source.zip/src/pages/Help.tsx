import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Phone, MessageCircle, Play, BookOpen, Headphones } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const tutorials = [
  { title: 'How to list your crop in 2 minutes', duration: '2:14', lang: 'Hindi' },
  { title: 'Booking cold storage step-by-step', duration: '2:48', lang: 'Marathi' },
  { title: 'Understanding lab quality grades', duration: '1:55', lang: 'Hindi' },
  { title: 'Comparing transport prices', duration: '2:30', lang: 'Punjabi' },
  { title: 'Reading mandi price trends', duration: '3:10', lang: 'Tamil' },
  { title: 'Voice commands you can use', duration: '1:40', lang: 'Hindi' },
];

const faqs = [
  { q: 'How do I get paid after selling?', a: 'Payment is transferred directly to your bank account within 24 hours of delivery confirmation by the wholesaler.' },
  { q: 'What if my crop quality is rejected?', a: 'You receive a detailed lab report. You can re-test or list at a lower grade. Aarohan never charges for rejected listings.' },
  { q: 'Can I cancel a transport booking?', a: 'Yes, free cancellation up to 1 hour before pickup. Otherwise, ₹200 cancellation fee applies.' },
  { q: 'Is voice login secure?', a: 'Voice prints are encrypted on-device and never stored on servers. OTP is still required for transactions.' },
];

const Help = () => {
  return (
    <div className="container py-6 space-y-6">
      <div className="rounded-2xl gradient-primary p-6 text-primary-foreground flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold">📞 24x7 Helpline</h1>
          <p className="opacity-90 text-sm mt-1">Speak to a real person in your language — anytime</p>
        </div>
        <div className="flex gap-2">
          <Button size="lg" variant="secondary" className="gap-2"><Phone className="h-5 w-5" />1800-AAROHAN</Button>
          <Button size="lg" className="bg-accent text-accent-foreground gap-2 hover:bg-accent/90"><MessageCircle className="h-5 w-5" />WhatsApp</Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="card-leaf p-5">
          <div className="flex items-center gap-2 mb-3"><Play className="h-5 w-5 text-accent" /><h2 className="font-heading font-bold">Video Tutorials</h2></div>
          <div className="grid sm:grid-cols-2 gap-3">
            {tutorials.map((v, i) => (
              <button key={i} className="text-left p-3 rounded-xl bg-secondary hover:bg-primary/10 transition group">
                <div className="aspect-video rounded-lg bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center mb-2 group-hover:scale-[1.02] transition">
                  <Play className="h-8 w-8 text-primary-foreground bg-primary/80 rounded-full p-2" />
                </div>
                <div className="font-semibold text-sm">{v.title}</div>
                <div className="text-xs text-muted-foreground">{v.duration} • {v.lang}</div>
              </button>
            ))}
          </div>
        </Card>

        <div className="space-y-6">
          <Card className="card-leaf p-5">
            <div className="flex items-center gap-2 mb-3"><BookOpen className="h-5 w-5 text-primary" /><h2 className="font-heading font-bold">Onboarding Guide</h2></div>
            <ol className="space-y-3 text-sm">
              {['Register with your mobile number', 'Complete KYC with Aadhaar', 'Add your first crop listing', 'Get a lab certification', 'Receive offers & sell direct'].map((s, i) => (
                <li key={i} className="flex gap-3">
                  <span className="h-7 w-7 shrink-0 rounded-full gradient-primary text-primary-foreground flex items-center justify-center font-bold text-xs">{i + 1}</span>
                  <span className="pt-1">{s}</span>
                </li>
              ))}
            </ol>
          </Card>

          <Card className="card-leaf p-5">
            <div className="flex items-center gap-2 mb-3"><Headphones className="h-5 w-5 text-accent" /><h2 className="font-heading font-bold">Live Voice Assistant</h2></div>
            <p className="text-sm text-muted-foreground mb-3">Ask anything in Hindi, Marathi, Punjabi, Tamil and more — instant voice replies.</p>
            <Button className="w-full gradient-accent text-accent-foreground gap-2" onClick={() => toast({ title: '🎤 Voice assistant ready' })}>
              <Headphones className="h-4 w-4" /> Start Voice Chat
            </Button>
          </Card>
        </div>
      </div>

      <Card className="card-leaf p-5">
        <h2 className="font-heading font-bold mb-3">Frequently Asked Questions</h2>
        <Accordion type="single" collapsible>
          {faqs.map((f, i) => (
            <AccordionItem key={i} value={`item-${i}`}>
              <AccordionTrigger className="font-semibold text-left">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </Card>

      <Card className="card-leaf p-5">
        <h2 className="font-heading font-bold mb-3">Submit a Grievance</h2>
        <div className="grid md:grid-cols-2 gap-3">
          <div><Label>Subject</Label><Input placeholder="Brief subject" /></div>
          <div><Label>Category</Label><Input placeholder="Payment / Quality / Transport" /></div>
        </div>
        <div className="mt-3"><Label>Describe your issue</Label><Textarea rows={4} placeholder="Tell us what happened…" /></div>
        <Button className="mt-4 gradient-primary text-primary-foreground" onClick={() => toast({ title: '✅ Ticket created — #AGH-2401' })}>Submit Grievance</Button>
      </Card>
    </div>
  );
};

export default Help;
