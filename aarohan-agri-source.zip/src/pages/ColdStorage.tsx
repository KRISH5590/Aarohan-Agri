import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Star, MapPin, Snowflake, AlertCircle } from 'lucide-react';
import { coldStorages } from '@/lib/mockData';
import { toast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';

const ColdStorage = () => {
  const [selected, setSelected] = useState<number[]>([]);
  const toggle = (id: number) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : s.length < 3 ? [...s, id] : s);

  const tagColor = (type: string) => type === 'Govt' ? 'bg-primary text-primary-foreground' : type === 'Co-op' ? 'bg-accent text-accent-foreground' : 'bg-secondary text-secondary-foreground';

  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold">🧊 Cold Storage Finder</h1>
        <p className="text-muted-foreground mt-1">Store your crop and sell when prices peak</p>
      </div>

      <Card className="p-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Find storage near Indore, MP" className="pl-10 h-12" />
          </div>
          <Button className="h-12 gradient-primary text-primary-foreground px-6">Search</Button>
        </div>
      </Card>

      <div className="grid lg:grid-cols-3 gap-4">
        {coldStorages.map((s, i) => {
          const isBest = i === 0;
          const isNearest = s.distance === Math.min(...coldStorages.map(x => x.distance));
          return (
            <Card key={s.id} className="card-leaf p-5 relative">
              {isBest && <Badge className="absolute -top-2 right-3 bg-success text-success-foreground">Best Value</Badge>}
              {isNearest && !isBest && <Badge className="absolute -top-2 right-3 bg-accent text-accent-foreground">Nearest</Badge>}
              <div className="flex items-center justify-between mb-3">
                <Snowflake className="h-8 w-8 text-primary" />
                <Badge className={tagColor(s.type)}>{s.type}</Badge>
              </div>
              <h3 className="font-heading font-bold text-lg">{s.name}</h3>
              <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{s.distance} km</span>
                <span className="inline-flex items-center gap-1"><Star className="h-3 w-3 fill-accent text-accent" />{s.rating}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
                <div className="p-2 rounded-lg bg-secondary">
                  <div className="text-muted-foreground text-xs">Price</div>
                  <div className="font-bold">₹{s.price}/q/day</div>
                </div>
                <div className="p-2 rounded-lg bg-secondary">
                  <div className="text-muted-foreground text-xs">Capacity</div>
                  <div className="font-bold">{s.capacity}</div>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="flex-1 gradient-primary text-primary-foreground">Book</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Confirm booking — {s.name}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between"><span>Quantity</span><span className="font-semibold">50 quintals</span></div>
                      <div className="flex justify-between"><span>Duration</span><span className="font-semibold">30 days</span></div>
                      <div className="flex justify-between"><span>Rate</span><span className="font-semibold">₹{s.price}/q/day</span></div>
                      <div className="flex justify-between border-t pt-2"><span className="font-bold">Total</span><span className="font-bold text-primary">₹{(s.price * 50 * 30).toLocaleString('en-IN')}</span></div>
                      <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20 flex gap-2 text-xs">
                        <AlertCircle className="h-4 w-4 text-destructive shrink-0" />
                        <span><strong>Cancellation policy:</strong> Within 24hrs: ₹200 charge. After 24hrs: 10% of booking.</span>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button onClick={() => toast({ title: '✅ Booking confirmed!' })} className="gradient-primary text-primary-foreground">Confirm Booking</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                <Button variant={selected.includes(s.id) ? 'default' : 'outline'} size="sm" onClick={() => toggle(s.id)}>
                  {selected.includes(s.id) ? '✓' : 'Compare'}
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {selected.length > 0 && (
        <Card className="p-4 border-2 border-accent">
          <h3 className="font-heading font-bold mb-3">Comparison ({selected.length} selected)</h3>
          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr><th className="p-2">Name</th><th className="p-2">Distance</th><th className="p-2">Price</th><th className="p-2">Capacity</th><th className="p-2">Rating</th></tr>
              </thead>
              <tbody>
                {coldStorages.filter(c => selected.includes(c.id)).map(c => (
                  <tr key={c.id} className="border-t border-border">
                    <td className="p-2 font-semibold">{c.name}</td>
                    <td className="p-2">{c.distance} km</td>
                    <td className="p-2">₹{c.price}/q/day</td>
                    <td className="p-2">{c.capacity}</td>
                    <td className="p-2">⭐ {c.rating}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Card className="p-4">
        <h3 className="font-heading font-bold mb-2">Cold Storage Map</h3>
        <div className="h-64 rounded-lg bg-gradient-to-br from-blue-50 to-primary/10 flex items-center justify-center border border-border">
          <div className="text-center">
            <Snowflake className="h-8 w-8 mx-auto text-primary mb-2" />
            <p className="text-sm text-muted-foreground">{coldStorages.length} cold storage facilities • Color coded by price</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ColdStorage;
