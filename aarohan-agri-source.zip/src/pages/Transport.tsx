import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Truck, Star, AlertTriangle, Phone, Sparkles } from 'lucide-react';
import { transportProviders } from '@/lib/mockData';
import { toast } from '@/hooks/use-toast';

const Transport = () => {
  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold">🚛 Book Transport</h1>
        <p className="text-muted-foreground mt-1">Compare prices from Porter, Loadshare, Vahak instantly</p>
      </div>

      <Card className="card-leaf p-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label>Pickup Location</Label>
            <Input defaultValue="Mhow, Indore (MP)" />
          </div>
          <div>
            <Label>Delivery Location</Label>
            <Input defaultValue="Indore Mandi, Sanyogitaganj" />
          </div>
        </div>
        <div className="mt-3 p-3 rounded-lg bg-accent/10 border border-accent/30 flex items-center gap-2 text-sm">
          <Sparkles className="h-4 w-4 text-accent" />
          <span>AI calculated distance: <strong>23 km</strong> • Estimated travel: <strong>45 min</strong></span>
        </div>
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        {transportProviders.map((p, i) => {
          const isBest = i === 1;
          return (
            <Card key={p.id} className={`card-leaf p-5 relative ${isBest ? 'border-l-accent ring-2 ring-accent/30' : ''}`}>
              {isBest && <Badge className="absolute -top-2 right-3 bg-accent text-accent-foreground">Best Option</Badge>}
              <div className="flex items-center gap-2 mb-2">
                <Truck className="h-6 w-6 text-primary" />
                <h3 className="font-heading font-bold text-lg">{p.name}</h3>
              </div>
              <p className="text-sm text-muted-foreground">{p.vehicle}</p>
              <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
                <div className="p-2 rounded-lg bg-secondary">
                  <div className="text-xs text-muted-foreground">Time</div>
                  <div className="font-bold">{p.time}</div>
                </div>
                <div className="p-2 rounded-lg bg-secondary">
                  <div className="text-xs text-muted-foreground">Rating</div>
                  <div className="font-bold inline-flex items-center gap-1"><Star className="h-3 w-3 fill-accent text-accent" />{p.rating}</div>
                </div>
              </div>
              <div className="mt-4 flex items-end justify-between">
                <div>
                  <div className="text-xs text-muted-foreground">Total</div>
                  <div className="font-heading text-2xl font-bold text-primary">₹{p.price}</div>
                </div>
                <Button onClick={() => toast({ title: `OTP sent — Booking ${p.name}` })} className="gradient-primary text-primary-foreground">Book Now</Button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-3">Cancellation: Free up to 1 hr before pickup</p>
            </Card>
          );
        })}
      </div>

      <Card className="p-5">
        <h3 className="font-heading font-bold mb-2">Live Tracking</h3>
        <div className="h-56 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center border border-border">
          <div className="text-center">
            <Truck className="h-10 w-10 mx-auto text-primary mb-2 animate-pulse" />
            <p className="font-semibold">Book transport to enable live tracking</p>
            <p className="text-xs text-muted-foreground mt-1">Real-time GPS map with ETA updates</p>
          </div>
        </div>
      </Card>

      <Card className="p-5 border-l-4 border-l-destructive bg-destructive/5">
        <div className="flex items-center gap-3">
          <AlertTriangle className="h-6 w-6 text-destructive" />
          <div className="flex-1">
            <h4 className="font-bold">Transport Emergency?</h4>
            <p className="text-sm text-muted-foreground">If your driver cancels or is delayed, we'll arrange a replacement immediately.</p>
          </div>
          <Button variant="destructive" className="gap-2"><Phone className="h-4 w-4" />Helpline</Button>
        </div>
      </Card>
    </div>
  );
};

export default Transport;
