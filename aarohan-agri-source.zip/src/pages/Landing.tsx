import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Sprout, Mic, Phone, Mail, Wheat, Store, Snowflake, Truck, ShieldCheck, ArrowRight, BadgeCheck, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { LanguageSelector } from '@/components/LanguageSelector';
import { toast } from '@/hooks/use-toast';
import heroImg from '@/assets/hero-farmland.jpg';

const roles = [
  { key: 'farmer', icon: Wheat, emoji: '🌾' },
  { key: 'wholesaler', icon: Store, emoji: '🏪' },
  { key: 'coldStorage', icon: Snowflake, emoji: '🧊' },
  { key: 'transport', icon: Truck, emoji: '🚛' },
  { key: 'admin', icon: ShieldCheck, emoji: '🛠️' },
];

const stats = [
  { value: '12,000+', label: 'Farmers' },
  { value: '₹47 Cr', label: 'Saved' },
  { value: '340+', label: 'Verified Buyers' },
  { value: '5 States', label: 'Active' },
];

const Landing = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  const handleSendOtp = () => {
    if (mobile.length < 10) return toast({ title: 'Enter valid mobile', variant: 'destructive' });
    setOtpSent(true);
    toast({ title: '✅ OTP sent', description: 'Use 1234 for demo login' });
  };

  const handleLogin = (role: string) => {
    toast({ title: `Welcome ${t(role)}! 🌾` });
    navigate(role === 'wholesaler' ? '/wholesaler' : '/dashboard');
  };

  return (
    <div className="min-h-screen w-full relative overflow-hidden">
      {/* Hero background */}
      <div className="absolute inset-0">
        <img src={heroImg} alt="Indian farmland" className="absolute inset-0 w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 gradient-hero" />
        <div className="absolute inset-0 particle-overlay" />
      </div>

      {/* Top bar */}
      <header className="relative z-10 container flex items-center justify-between py-5">
        <div className="flex items-center gap-2 text-primary-foreground">
          <span className="h-10 w-10 rounded-xl bg-primary-foreground/15 backdrop-blur flex items-center justify-center border border-primary-foreground/25">
            <Sprout className="h-5 w-5" />
          </span>
          <span className="font-heading font-bold text-xl">{t('appName')}</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => toast({ title: '🎤 ' + t('voiceLogin') })}
            className="hidden sm:flex items-center gap-2 h-9 px-3 rounded-md bg-accent text-accent-foreground text-sm font-medium shadow-glow animate-pulse-glow"
            title={t('voiceLogin')}
          >
            <Mic className="h-4 w-4" /> {t('voiceLogin')}
          </button>
          <LanguageSelector variant="light" />
        </div>
      </header>

      {/* Main */}
      <div className="relative z-10 container grid lg:grid-cols-2 gap-10 items-center pt-6 pb-32 md:pb-20">
        {/* Left — Hero copy */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-primary-foreground space-y-6"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/20 border border-accent/40 text-sm font-medium backdrop-blur">
            <BadgeCheck className="h-4 w-4 text-accent" /> Government APMC Verified
          </span>
          <h1 className="font-heading text-4xl md:text-6xl font-extrabold leading-tight">
            <span className="block">अपनी फसल,</span>
            <span className="block text-gradient-accent">अपना दाम</span>
            <span className="block text-2xl md:text-3xl font-semibold opacity-95 mt-2">
              {t('tagline')}
            </span>
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/90 max-w-xl">
            India's first AI-powered platform connecting farmers directly to wholesalers, cold storage and transport — no middlemen, more profit.
          </p>

          {/* Trust badges */}
          <div className="flex flex-wrap gap-3 pt-2">
            {['Government APMC Verified', 'ISO Certified', 'Data Secure'].map(b => (
              <span key={b} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary-foreground/10 border border-primary-foreground/25 text-xs font-medium backdrop-blur">
                <Lock className="h-3 w-3" /> {b}
              </span>
            ))}
          </div>
        </motion.div>

        {/* Right — Login card */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
        >
          <Card className="p-6 md:p-8 shadow-elevated border-0 bg-card/95 backdrop-blur-xl">
            <div className="space-y-1 mb-5">
              <h2 className="font-heading text-2xl font-bold text-primary">{t('loginTitle')}</h2>
              <p className="text-sm text-muted-foreground">Login with mobile OTP or email</p>
            </div>

            <Tabs defaultValue="mobile" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="mobile" className="gap-2"><Phone className="h-4 w-4" />{t('mobile')}</TabsTrigger>
                <TabsTrigger value="email" className="gap-2"><Mail className="h-4 w-4" />Email</TabsTrigger>
              </TabsList>

              <TabsContent value="mobile" className="space-y-3 pt-4">
                <div className="flex gap-2">
                  <span className="inline-flex items-center px-3 rounded-md bg-secondary text-sm font-semibold">+91</span>
                  <Input value={mobile} onChange={e => setMobile(e.target.value)} placeholder="98765 43210" inputMode="numeric" maxLength={10} className="h-12" />
                </div>
                {otpSent && (
                  <Input value={otp} onChange={e => setOtp(e.target.value)} placeholder="Enter OTP (1234)" inputMode="numeric" maxLength={4} className="h-12 text-center font-mono text-lg tracking-widest" />
                )}
                <Button onClick={handleSendOtp} className="w-full h-12 gradient-primary text-primary-foreground font-semibold">
                  {otpSent ? 'Verify OTP' : t('sendOtp')} <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </TabsContent>

              <TabsContent value="email" className="space-y-3 pt-4">
                <Input type="email" placeholder="you@farm.com" className="h-12" />
                <Input type="password" placeholder="Password" className="h-12" />
                <Button className="w-full h-12 gradient-primary text-primary-foreground font-semibold">Login</Button>
              </TabsContent>
            </Tabs>

            <div className="my-5 flex items-center gap-3">
              <div className="h-px flex-1 bg-border" />
              <span className="text-xs text-muted-foreground font-medium">{t('loginAs')}</span>
              <div className="h-px flex-1 bg-border" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {roles.map(r => (
                <button
                  key={r.key}
                  onClick={() => handleLogin(r.key)}
                  className="group flex flex-col items-center gap-1 p-3 rounded-xl border border-border bg-card hover:border-primary hover:bg-primary/5 transition-all min-h-[80px]"
                >
                  <span className="text-2xl group-hover:scale-110 transition-transform">{r.emoji}</span>
                  <span className="text-xs font-semibold text-center leading-tight">{t(r.key)}</span>
                </button>
              ))}
            </div>

            <Link to="/dashboard" className="mt-5 block">
              <Button variant="outline" className="w-full h-12 border-accent text-accent hover:bg-accent hover:text-accent-foreground font-semibold">
                {t('registerCta')} <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>

            <button
              onClick={() => toast({ title: '🎤 ' + t('voiceLogin') })}
              className="mt-3 sm:hidden w-full inline-flex items-center justify-center gap-2 h-11 rounded-md bg-accent text-accent-foreground text-sm font-medium"
            >
              <Mic className="h-4 w-4" /> {t('voiceLogin')}
            </button>
          </Card>
        </motion.div>
      </div>

      {/* Stats ticker */}
      <div className="absolute bottom-0 left-0 right-0 z-10 bg-primary/95 backdrop-blur-md border-t border-primary-foreground/10 py-3 overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...stats, ...stats, ...stats].map((s, i) => (
            <div key={i} className="flex items-center gap-2 px-8 text-primary-foreground">
              <span className="font-heading font-bold text-accent text-lg">{s.value}</span>
              <span className="text-sm opacity-90">{s.label}</span>
              <span className="opacity-30 ml-4">•</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Landing;
