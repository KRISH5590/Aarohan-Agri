import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Bell, Wheat, Snowflake, Truck, FlaskConical, Phone, TrendingUp, TrendingDown, BadgeCheck, Sparkles } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart, CartesianGrid } from 'recharts';
import { mandiPrices, priceTrend7d, priceTrend30d, FARMER_NAME } from '@/lib/mockData';
import { useState } from 'react';

const Dashboard = () => {
  const { t } = useTranslation();
  const [range, setRange] = useState<'7d' | '30d'>('7d');
  const data = range === '7d' ? priceTrend7d : priceTrend30d;

  const middleman = 4200;
  const direct = 5230;
  const extra = direct - middleman;

  const quickActions = [
    { icon: Wheat, label: 'List Crop', to: '/marketplace', emoji: '📦', color: 'bg-primary/10 text-primary' },
    { icon: Snowflake, label: 'Cold Storage', to: '/cold-storage', emoji: '🧊', color: 'bg-blue-100 text-blue-700' },
    { icon: Truck, label: 'Transport', to: '/transport', emoji: '🚛', color: 'bg-amber-100 text-amber-700' },
    { icon: FlaskConical, label: 'Lab Test', to: '/lab', emoji: '🧪', color: 'bg-purple-100 text-purple-700' },
    { icon: Phone, label: 'Helpline', to: '/help', emoji: '📞', color: 'bg-rose-100 text-rose-700' },
  ];

  return (
    <div className="container py-6 space-y-6">
      {/* Welcome banner */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl gradient-primary p-6 text-primary-foreground shadow-card">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="font-heading text-2xl md:text-3xl font-bold">
              {t('namaste')} {FARMER_NAME} 🌾
            </h1>
            <div className="flex items-center gap-2 mt-2">
              <BadgeCheck className="h-5 w-5 text-accent" />
              <span className="text-sm font-medium">{t('certifiedFarmer')}</span>
            </div>
          </div>
          <div className="min-w-[200px]">
            <div className="text-xs opacity-90 mb-1">Profile completeness</div>
            <Progress value={78} className="h-2 bg-primary-foreground/20" />
            <div className="text-xs mt-1 opacity-90">78% • Add KYC to reach 100%</div>
          </div>
        </div>
      </motion.div>

      {/* Profit comparison — most prominent */}
      <Card className="card-leaf p-6 border-l-accent">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="h-5 w-5 text-accent" />
          <h2 className="font-heading text-lg font-bold">Today's Profit Comparison — Soybean (50q)</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="p-5 rounded-xl bg-muted/60 border border-border">
            <div className="text-sm text-muted-foreground mb-1">Sell to Middleman</div>
            <div className="font-heading text-3xl font-bold text-foreground">₹{(middleman * 50).toLocaleString('en-IN')}</div>
            <div className="text-xs text-muted-foreground mt-1">@ ₹{middleman}/quintal</div>
          </div>
          <div className="relative p-5 rounded-xl bg-success/10 border-2 border-success">
            <Badge className="absolute -top-3 right-4 bg-success text-success-foreground">Recommended</Badge>
            <div className="text-sm text-success font-semibold mb-1">Sell Direct to Wholesaler</div>
            <div className="font-heading text-3xl font-bold text-success">₹{(direct * 50).toLocaleString('en-IN')}</div>
            <div className="text-xs text-success/80 mt-1">@ ₹{direct}/quintal • +₹{(extra * 50).toLocaleString('en-IN')} extra</div>
          </div>
        </div>
        <Link to="/marketplace">
          <Button className="mt-4 gradient-accent text-accent-foreground font-semibold">View Buyers Now →</Button>
        </Link>
      </Card>

      {/* Mandi ticker */}
      <Card className="overflow-hidden">
        <div className="px-4 py-2 bg-secondary flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-success animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wide">Live Mandi Prices</span>
        </div>
        <div className="overflow-hidden py-3">
          <div className="flex animate-marquee whitespace-nowrap">
            {[...mandiPrices, ...mandiPrices].map((m, i) => (
              <div key={i} className="flex items-center gap-2 px-6 text-sm">
                <span className="font-semibold">{m.crop}</span>
                <span className="text-muted-foreground">({m.mandi})</span>
                <span className="font-mono font-bold">₹{m.price}</span>
                <span className={`inline-flex items-center text-xs font-semibold ${m.change >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {m.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {Math.abs(m.change)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Trend chart */}
        <Card className="card-leaf p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-heading font-bold">Soybean Price Trend</h3>
            <div className="flex gap-1 p-1 bg-secondary rounded-lg">
              {(['7d', '30d'] as const).map(r => (
                <button key={r} onClick={() => setRange(r)} className={`px-3 py-1 text-xs font-semibold rounded-md transition ${range === r ? 'bg-card shadow-soft' : 'text-muted-foreground'}`}>
                  {r === '7d' ? '7 Days' : '30 Days'}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colP" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))' }} />
              <Area type="monotone" dataKey="price" stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#colP)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Price alert */}
        <Card className="card-leaf p-5 border-l-accent bg-gradient-to-br from-accent/5 to-transparent">
          <div className="flex items-center gap-2 mb-2">
            <Bell className="h-5 w-5 text-accent animate-pulse" />
            <span className="font-heading font-bold">Fair Price Alert</span>
          </div>
          <p className="text-sm leading-relaxed">
            🔔 Soybean price hit <span className="font-bold text-accent">₹5,200/quintal</span> in Indore Mandi — Best time to sell!
          </p>
          <Link to="/marketplace">
            <Button size="sm" className="mt-3 gradient-accent text-accent-foreground">Sell Now</Button>
          </Link>
          <div className="mt-5 pt-4 border-t border-border space-y-2 text-xs">
            <div className="flex justify-between"><span className="text-muted-foreground">Buyer offer received</span><span className="font-semibold">2 mins ago</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Lab result ready</span><span className="font-semibold">1 hr ago</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Transport confirmed</span><span className="font-semibold">3 hrs ago</span></div>
          </div>
        </Card>
      </div>

      {/* Quick actions */}
      <div>
        <h2 className="font-heading text-lg font-bold mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {quickActions.map(a => (
            <Link key={a.label} to={a.to}>
              <Card className="card-leaf p-4 text-center cursor-pointer h-full">
                <div className="text-3xl mb-2">{a.emoji}</div>
                <div className="font-semibold text-sm">{a.label}</div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
