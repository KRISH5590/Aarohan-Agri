import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { FlaskConical, Upload, Sparkles, BadgeCheck, Download, Droplet, Thermometer, Beaker } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { labs } from '@/lib/mockData';
import { toast } from '@/hooks/use-toast';

const Lab = () => {
  return (
    <div className="container py-6 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold">🧪 Quality & Lab Testing</h1>
        <p className="text-muted-foreground mt-1">Get certified, sell at premium prices</p>
      </div>

      <Tabs defaultValue="book">
        <TabsList className="grid grid-cols-3 max-w-xl">
          <TabsTrigger value="book">Book Test</TabsTrigger>
          <TabsTrigger value="ai">AI Quality Check</TabsTrigger>
          <TabsTrigger value="iot">IoT Sensors</TabsTrigger>
        </TabsList>

        <TabsContent value="book" className="space-y-4 pt-4">
          <Card className="card-leaf p-6">
            <h3 className="font-heading font-bold mb-4">Book a Lab Test</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div><Label>Crop Type</Label><Input defaultValue="Soybean" /></div>
              <div><Label>Quantity</Label><Input defaultValue="50 quintals" /></div>
              <div><Label>Location</Label><Input defaultValue="Mhow, Indore" /></div>
              <div><Label>Preferred Date</Label><Input type="date" /></div>
            </div>
            <div className="mt-4">
              <Label>Or upload existing certificate</Label>
              <button className="w-full h-20 mt-1 rounded-lg border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition flex items-center justify-center gap-2 text-muted-foreground">
                <Upload className="h-4 w-4" /> Upload existing lab report
              </button>
            </div>
          </Card>

          <div className="grid md:grid-cols-3 gap-4">
            {labs.map(l => (
              <Card key={l.id} className="card-leaf p-5">
                <div className="flex items-center justify-between">
                  <FlaskConical className="h-6 w-6 text-primary" />
                  <Badge className="bg-success text-success-foreground">{l.accredited}</Badge>
                </div>
                <h4 className="font-heading font-bold mt-3">{l.name}</h4>
                <div className="text-xs text-muted-foreground mt-1">{l.distance} km away</div>
                <div className="grid grid-cols-2 gap-2 mt-3 text-sm">
                  <div className="p-2 rounded-lg bg-secondary"><div className="text-xs text-muted-foreground">Time</div><div className="font-bold">{l.days} days</div></div>
                  <div className="p-2 rounded-lg bg-secondary"><div className="text-xs text-muted-foreground">Price</div><div className="font-bold">₹{l.price}</div></div>
                </div>
                <Button className="w-full mt-3 gradient-primary text-primary-foreground" onClick={() => toast({ title: `Test booked at ${l.name}` })}>Book</Button>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai" className="pt-4">
          <Card className="card-leaf p-6 text-center">
            <Sparkles className="h-12 w-12 mx-auto text-accent mb-3" />
            <h3 className="font-heading text-xl font-bold">AI Crop Quality Analysis</h3>
            <p className="text-sm text-muted-foreground mt-1 mb-5">Upload a photo of your crop and get instant grade estimate</p>
            <button className="w-full max-w-md mx-auto h-40 rounded-xl border-2 border-dashed border-primary/40 hover:bg-primary/5 transition flex flex-col items-center justify-center gap-2">
              <Upload className="h-8 w-8 text-primary" />
              <span className="font-semibold">Upload crop photo</span>
              <span className="text-xs text-muted-foreground">JPG, PNG up to 5MB</span>
            </button>
            <div className="mt-6 max-w-md mx-auto p-4 rounded-xl bg-success/10 border border-success/30">
              <div className="text-sm text-muted-foreground">Last analysis</div>
              <div className="font-heading text-2xl font-bold text-success mt-1">Grade A — 92% Quality</div>
              <div className="text-xs text-muted-foreground mt-1">Moisture: 11.2% • Foreign matter: 0.8%</div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="iot" className="pt-4">
          <Card className="card-leaf p-6">
            <h3 className="font-heading font-bold mb-4">🌱 IoT Sensor Dashboard</h3>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { icon: Droplet, label: 'Soil Moisture', value: 68, unit: '%', color: 'text-blue-600' },
                { icon: Thermometer, label: 'Temperature', value: 28, unit: '°C', color: 'text-orange-600' },
                { icon: Beaker, label: 'pH Level', value: 6.8, unit: '', color: 'text-purple-600' },
              ].map(s => (
                <div key={s.label} className="p-5 rounded-xl bg-secondary text-center">
                  <s.icon className={`h-8 w-8 mx-auto ${s.color} mb-2`} />
                  <div className="text-sm text-muted-foreground">{s.label}</div>
                  <div className="font-heading text-3xl font-bold">{s.value}<span className="text-lg ml-1">{s.unit}</span></div>
                  <Progress value={s.label === 'pH Level' ? s.value * 10 : s.value} className="h-1.5 mt-2" />
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="card-leaf p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-heading font-bold">Testing History</h3>
          <Badge className="gap-1 bg-success text-success-foreground"><BadgeCheck className="h-3 w-3" />Certified Farmer</Badge>
        </div>
        <div className="space-y-3">
          {[
            { date: '12 Mar 2025', crop: 'Soybean', grade: 'A', lab: 'AgriCert Indore' },
            { date: '02 Feb 2025', crop: 'Wheat', grade: 'A+', lab: 'Bayer Lab' },
            { date: '18 Jan 2025', crop: 'Gram', grade: 'B', lab: 'MP Govt Lab' },
          ].map((h, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-secondary">
              <div>
                <div className="font-semibold">{h.crop} • Grade {h.grade}</div>
                <div className="text-xs text-muted-foreground">{h.lab} • {h.date}</div>
              </div>
              <Button size="sm" variant="outline" className="gap-1"><Download className="h-3 w-3" />PDF</Button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Lab;
