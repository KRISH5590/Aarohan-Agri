export const mandiPrices = [
  { crop: 'Wheat', mandi: 'Indore', price: 2450, change: +1.2 },
  { crop: 'Soybean', mandi: 'Indore', price: 5200, change: +3.4 },
  { crop: 'Gram', mandi: 'Bhopal', price: 5800, change: -0.8 },
  { crop: 'Onion', mandi: 'Nashik', price: 1850, change: +2.1 },
  { crop: 'Tomato', mandi: 'Pune', price: 2200, change: -1.5 },
  { crop: 'Mustard', mandi: 'Jaipur', price: 5400, change: +0.6 },
  { crop: 'Cotton', mandi: 'Akola', price: 7300, change: +2.8 },
  { crop: 'Maize', mandi: 'Davangere', price: 2100, change: +1.0 },
];

export const priceTrend7d = [
  { day: 'Mon', price: 5050 }, { day: 'Tue', price: 5100 }, { day: 'Wed', price: 5080 },
  { day: 'Thu', price: 5150 }, { day: 'Fri', price: 5180 }, { day: 'Sat', price: 5200 }, { day: 'Sun', price: 5230 },
];

export const priceTrend30d = Array.from({ length: 30 }, (_, i) => ({
  day: `D${i + 1}`,
  price: 4800 + Math.round(Math.sin(i / 3) * 150 + i * 12 + Math.random() * 80),
}));

export const buyerOffers = [
  { id: 1, name: 'Sharma Traders', price: 5280, distance: 12, rating: 4.8, verified: true, pickup: 'Today' },
  { id: 2, name: 'Krishi Wholesale Co.', price: 5320, distance: 24, rating: 4.6, verified: true, pickup: 'Tomorrow' },
  { id: 3, name: 'AgriMart India', price: 5250, distance: 8, rating: 4.9, verified: true, pickup: 'Today' },
  { id: 4, name: 'Bharat Mandi Co-op', price: 5350, distance: 35, rating: 4.5, verified: true, pickup: '2 days' },
];

export const coldStorages = [
  { id: 1, name: 'Indore Cold Chain', distance: 6, price: 2.5, capacity: '2400q', rating: 4.7, type: 'Private' },
  { id: 2, name: 'MP State Storage', distance: 14, price: 1.8, capacity: '5000q', rating: 4.4, type: 'Govt' },
  { id: 3, name: 'Krishak Co-op Store', distance: 9, price: 2.0, capacity: '1800q', rating: 4.6, type: 'Co-op' },
  { id: 4, name: 'Reliance Fresh Cold', distance: 18, price: 3.2, capacity: '8000q', rating: 4.8, type: 'Private' },
];

export const transportProviders = [
  { id: 1, name: 'Porter', vehicle: 'Tata Ace (750kg)', time: '4 hrs', price: 2400, rating: 4.5 },
  { id: 2, name: 'Loadshare', vehicle: 'Pickup (1.5T)', time: '5 hrs', price: 2100, rating: 4.6 },
  { id: 3, name: 'Vahak', vehicle: 'Truck (4T)', time: '6 hrs', price: 3200, rating: 4.4 },
];

export const labs = [
  { id: 1, name: 'AgriCert Labs Indore', distance: 8, days: 2, price: 450, accredited: 'NABL' },
  { id: 2, name: 'MP Govt Quality Lab', distance: 15, days: 3, price: 200, accredited: 'FSSAI' },
  { id: 3, name: 'Bayer Crop Science Lab', distance: 22, days: 1, price: 750, accredited: 'NABL' },
];

export const demandForecast = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  demand: 60 + Math.round(Math.sin(i / 4) * 15 + i * 0.8),
  forecast: 60 + Math.round(Math.sin(i / 4) * 15 + i * 0.8 + 8),
}));

export const FARMER_NAME = 'Ramesh Patel';
export const FARMER_VILLAGE = 'Mhow, Indore (MP)';
