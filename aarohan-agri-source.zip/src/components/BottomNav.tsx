import { NavLink, useLocation } from 'react-router-dom';
import { Home, Store, Snowflake, Truck, User } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const items = [
  { to: '/dashboard', icon: Home, key: 'home' },
  { to: '/marketplace', icon: Store, key: 'market' },
  { to: '/cold-storage', icon: Snowflake, key: 'storage' },
  { to: '/transport', icon: Truck, key: 'transport' },
  { to: '/profile', icon: User, key: 'profile' },
];

const labels: Record<string, string> = {
  home: 'Home', market: 'Market', storage: 'Storage', transport: 'Transport', profile: 'Profile',
};

export const BottomNav = () => {
  const location = useLocation();
  if (location.pathname === '/') return null;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-background/95 backdrop-blur-lg border-t border-border shadow-elevated">
      <div className="grid grid-cols-5 h-16">
        {items.map(({ to, icon: Icon, key }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center gap-1 transition-colors ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`
            }
          >
            <Icon className="h-5 w-5" />
            <span className="text-[10px] font-medium">{labels[key]}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};
