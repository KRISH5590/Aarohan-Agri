import { Link, useLocation } from 'react-router-dom';
import { Bell, LogOut, Sprout, User } from 'lucide-react';
import { LanguageSelector } from './LanguageSelector';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export const Navbar = () => {
  const location = useLocation();
  const isLanding = location.pathname === '/';
  if (isLanding) return null;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/85 backdrop-blur-lg">
      <div className="container flex h-16 items-center justify-between gap-4">
        <Link to="/dashboard" className="flex items-center gap-2 font-heading font-bold text-lg">
          <span className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center shadow-soft">
            <Sprout className="h-5 w-5 text-primary-foreground" />
          </span>
          <span className="text-primary">Aarohan</span>
          <span className="text-accent">Agri</span>
        </Link>

        <div className="flex items-center gap-2">
          <LanguageSelector />
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-accent text-accent-foreground">3</Badge>
          </Button>
          <Link to="/profile">
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
            </Button>
          </Link>
          <Link to="/" className="hidden sm:block">
            <Button variant="ghost" size="icon" aria-label="Logout">
              <LogOut className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </header>
  );
};
