import { useState } from 'react';
import { Mic } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { toast } from '@/hooks/use-toast';

export const VoiceAssistant = () => {
  const { t } = useTranslation();
  const [listening, setListening] = useState(false);

  const handleClick = () => {
    setListening(true);
    toast({
      title: '🎤 ' + t('needHelp'),
      description: 'Voice assistant is listening… (demo)',
    });
    setTimeout(() => setListening(false), 2500);
  };

  return (
    <button
      onClick={handleClick}
      aria-label={t('voiceLogin')}
      className={`fixed bottom-24 md:bottom-8 right-6 z-50 h-16 w-16 rounded-full gradient-accent text-accent-foreground shadow-glow flex items-center justify-center transition-transform hover:scale-110 ${listening ? 'animate-pulse-glow' : ''}`}
    >
      <Mic className="h-7 w-7" />
    </button>
  );
};
