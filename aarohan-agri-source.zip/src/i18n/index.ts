import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const t = {
  // Common
  appName: { en: 'Aarohan Agri', hi: 'आरोहण कृषि', mr: 'आरोहण कृषी', pa: 'ਆਰੋਹਣ ਖੇਤੀ', gu: 'આરોહણ કૃષિ', ta: 'ஆரோகண் வேளாண்', te: 'ఆరోహణ్ వ్యవసాయం', kn: 'ಆರೋಹಣ ಕೃಷಿ', bn: 'আরোহণ কৃষি', or: 'ଆରୋହଣ କୃଷି' },
  tagline: { en: 'Your Crop, Your Price — Direct to Market', hi: 'अपनी फसल, अपना दाम — सीधा बाज़ार तक', mr: 'आपलं पीक, आपला भाव — थेट बाजारात', pa: 'ਆਪਣੀ ਫਸਲ, ਆਪਣਾ ਮੁੱਲ — ਸਿੱਧਾ ਬਾਜ਼ਾਰ', gu: 'તમારો પાક, તમારી કિંમત — સીધો બજાર', ta: 'உங்கள் பயிர், உங்கள் விலை — நேரடியாக சந்தைக்கு', te: 'మీ పంట, మీ ధర — నేరుగా మార్కెట్‌కి', kn: 'ನಿಮ್ಮ ಬೆಳೆ, ನಿಮ್ಮ ಬೆಲೆ — ನೇರವಾಗಿ ಮಾರುಕಟ್ಟೆಗೆ', bn: 'আপনার ফসল, আপনার দাম — সরাসরি বাজারে', or: 'ଆପଣଙ୍କ ଫସଲ, ଆପଣଙ୍କ ଦାମ — ସିଧା ବଜାର' },
  loginTitle: { en: 'Welcome Back', hi: 'वापसी पर स्वागत है', mr: 'पुन्हा स्वागत', pa: 'ਮੁੜ ਜੀ ਆਇਆਂ ਨੂੰ', gu: 'પાછા સ્વાગત', ta: 'மீண்டும் வரவேற்கிறோம்', te: 'తిరిగి స్వాగతం', kn: 'ಮರಳಿ ಸ್ವಾಗತ', bn: 'আবার স্বাগতম', or: 'ପୁଣି ସ୍ୱାଗତ' },
  mobile: { en: 'Mobile Number', hi: 'मोबाइल नंबर', mr: 'मोबाइल नंबर', pa: 'ਮੋਬਾਈਲ ਨੰਬਰ', gu: 'મોબાઈલ નંબર', ta: 'மொபைல் எண்', te: 'మొబైల్ నంబర్', kn: 'ಮೊಬೈಲ್ ಸಂಖ್ಯೆ', bn: 'মোবাইল নম্বর', or: 'ମୋବାଇଲ୍ ନମ୍ବର' },
  sendOtp: { en: 'Send OTP', hi: 'OTP भेजें', mr: 'OTP पाठवा', pa: 'OTP ਭੇਜੋ', gu: 'OTP મોકલો', ta: 'OTP அனுப்பு', te: 'OTP పంపండి', kn: 'OTP ಕಳುಹಿಸಿ', bn: 'OTP পাঠান', or: 'OTP ପଠାନ୍ତୁ' },
  loginAs: { en: 'Login as', hi: 'के रूप में लॉगिन करें', mr: 'म्हणून लॉगिन', pa: 'ਵਜੋਂ ਲਾਗਇਨ', gu: 'તરીકે લોગિન', ta: 'ஆக உள்நுழைய', te: 'గా లాగిన్', kn: 'ಆಗಿ ಲಾಗಿನ್', bn: 'হিসাবে লগইন', or: 'ଭାବେ ଲଗଇନ୍' },
  farmer: { en: 'Farmer', hi: 'किसान', mr: 'शेतकरी', pa: 'ਕਿਸਾਨ', gu: 'ખેડૂત', ta: 'விவசாயி', te: 'రైతు', kn: 'ರೈತ', bn: 'কৃষক', or: 'କୃଷକ' },
  wholesaler: { en: 'Wholesaler/Retailer', hi: 'थोक/खुदरा विक्रेता', mr: 'घाऊक/किरकोळ', pa: 'ਥੋਕ/ਪ੍ਰਚੂਨ', gu: 'જથ્થાબંધ/છૂટક', ta: 'மொத்த/சில்லறை', te: 'హోల్‌సేల్/రిటైల్', kn: 'ಸಗಟು/ಚಿಲ್ಲರೆ', bn: 'পাইকারি/খুচরা', or: 'ପାଇକାରି/ଖୁଚୁରା' },
  coldStorage: { en: 'Cold Storage', hi: 'कोल्ड स्टोरेज', mr: 'कोल्ड स्टोरेज', pa: 'ਕੋਲਡ ਸਟੋਰੇਜ', gu: 'કોલ્ડ સ્ટોરેજ', ta: 'குளிர் சேமிப்பு', te: 'కోల్డ్ స్టోరేజ్', kn: 'ಶೀತಲ ಸಂಗ್ರಹ', bn: 'কোল্ড স্টোরেজ', or: 'କୋଲ୍ଡ ଷ୍ଟୋରେଜ୍' },
  transport: { en: 'Transport', hi: 'परिवहन', mr: 'वाहतूक', pa: 'ਆਵਾਜਾਈ', gu: 'પરિવહન', ta: 'போக்குவரத்து', te: 'రవాణా', kn: 'ಸಾರಿಗೆ', bn: 'পরিবহন', or: 'ପରିବହନ' },
  admin: { en: 'Admin', hi: 'व्यवस्थापक', mr: 'प्रशासक', pa: 'ਪ੍ਰਬੰਧਕ', gu: 'એડમિન', ta: 'நிர்வாகி', te: 'అడ్మిన్', kn: 'ಅಡ್ಮಿನ್', bn: 'অ্যাডমিন', or: 'ଆଡମିନ୍' },
  registerCta: { en: 'New here? Register your farm', hi: 'नए हैं? अपना खेत पंजीकृत करें', mr: 'नवीन आहात? तुमचे शेत नोंदवा', pa: 'ਨਵੇਂ ਹੋ? ਆਪਣਾ ਖੇਤ ਰਜਿਸਟਰ ਕਰੋ', gu: 'નવા છો? તમારું ખેતર નોંધો', ta: 'புதியவரா? உங்கள் பண்ணையை பதிவு செய்யுங்கள்', te: 'కొత్తవారా? మీ వ్యవసాయాన్ని నమోదు చేయండి', kn: 'ಹೊಸಬರಾ? ನಿಮ್ಮ ಕೃಷಿಯನ್ನು ನೋಂದಾಯಿಸಿ', bn: 'নতুন? আপনার খামার নিবন্ধন করুন', or: 'ନୂଆ? ଆପଣଙ୍କ ଚାଷ ପଞ୍ଜିକୃତ କରନ୍ତୁ' },
  voiceLogin: { en: 'Speak to login', hi: 'बोल के लॉगिन करो', mr: 'बोलून लॉगिन करा', pa: 'ਬੋਲ ਕੇ ਲਾਗਇਨ ਕਰੋ', gu: 'બોલીને લોગિન કરો', ta: 'பேசி உள்நுழையவும்', te: 'మాట్లాడి లాగిన్', kn: 'ಮಾತನಾಡಿ ಲಾಗಿನ್', bn: 'বলে লগইন করুন', or: 'କହି ଲଗଇନ୍ କରନ୍ତୁ' },
  // Dashboard
  namaste: { en: 'Hello', hi: 'नमस्ते', mr: 'नमस्कार', pa: 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ', gu: 'નમસ્તે', ta: 'வணக்கம்', te: 'నమస్తే', kn: 'ನಮಸ್ತೆ', bn: 'নমস্তে', or: 'ନମସ୍କାର' },
  certifiedFarmer: { en: 'Certified Farmer', hi: 'प्रमाणित किसान', mr: 'प्रमाणित शेतकरी', pa: 'ਪ੍ਰਮਾਣਿਤ ਕਿਸਾਨ', gu: 'પ્રમાણિત ખેડૂત', ta: 'சான்றளிக்கப்பட்ட விவசாயி', te: 'ధృవీకృత రైతు', kn: 'ಪ್ರಮಾಣೀಕೃತ ರೈತ', bn: 'প্রত্যয়িত কৃষক', or: 'ପ୍ରମାଣିତ କୃଷକ' },
  needHelp: { en: 'Need help?', hi: 'क्या मदद चाहिए?', mr: 'काही मदत हवी?', pa: 'ਕੀ ਮਦਦ ਚਾਹੀਦੀ?', gu: 'મદદ જોઈએ?', ta: 'உதவி வேண்டுமா?', te: 'సహాయం కావాలా?', kn: 'ಸಹಾಯ ಬೇಕೇ?', bn: 'সাহায্য চাই?', or: 'ସାହାଯ୍ୟ ଦରକାର?' },
};

const buildResources = () => {
  const langs = ['en','hi','mr','pa','gu','ta','te','kn','bn','or'] as const;
  const out: any = {};
  langs.forEach(l => {
    out[l] = { translation: {} };
    Object.entries(t).forEach(([k, v]: any) => { out[l].translation[k] = v[l] ?? v.en; });
  });
  return out;
};

i18n.use(LanguageDetector).use(initReactI18next).init({
  resources: buildResources(),
  fallbackLng: 'en',
  supportedLngs: ['en','hi','mr','pa','gu','ta','te','kn','bn','or'],
  interpolation: { escapeValue: false },
  detection: { order: ['localStorage', 'navigator'], caches: ['localStorage'] },
});

export const LANGUAGES = [
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'hi', label: 'हिन्दी', flag: '🇮🇳' },
  { code: 'mr', label: 'मराठी', flag: '🇮🇳' },
  { code: 'pa', label: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'gu', label: 'ગુજરાતી', flag: '🇮🇳' },
  { code: 'ta', label: 'தமிழ்', flag: '🇮🇳' },
  { code: 'te', label: 'తెలుగు', flag: '🇮🇳' },
  { code: 'kn', label: 'ಕನ್ನಡ', flag: '🇮🇳' },
  { code: 'bn', label: 'বাংলা', flag: '🇮🇳' },
  { code: 'or', label: 'ଓଡ଼ିଆ', flag: '🇮🇳' },
];

export default i18n;
